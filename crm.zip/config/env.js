/**
 * Created by hong.l on 2014/8/25.
 */
exports.env ={
    // connectionString:'mongodb://localhost/custmgr'
    connectionString:'mongodb://JaWKXOJi:HVZAV5o9Z2ko@10.0.31.20/custmgr'
}