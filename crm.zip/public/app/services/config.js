﻿'use strict';

define(['app'], function (app) {

    var value = {
        useBreeze: false
    };

    app.value('config', value);

});