﻿'use strict';

define(['app'], function (app) {

    var aboutController = function ($scope) {

    };

    app.register.controller('AboutController', ['$scope', aboutController]);

});